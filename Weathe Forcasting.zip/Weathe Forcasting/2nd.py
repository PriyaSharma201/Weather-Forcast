# import tkinter as tk
# from tkinter import messagebox
# import requests
# from datetime import datetime

# # Function to fetch weather data
# def get_weather():
#     city = city_entry.get()
#     if city == "":
#         messagebox.showwarning("Error", "Please fill in the city name!")
#         return
    
#     api_key = "YOUR_API_KEY"  # Replace with your actual API key
#     base_url = f"http://api.openweathermap.org/data/2.5/forecast?q={city}&appid=b26b6015799ef76e6864f993117dc7b4&units=metric"

#     try:
#         response = requests.get(base_url)
#         weather_data = response.json()

#         if weather_data['cod'] == '200':
#             # Initialize lists to store time, cloud cover, and temperature
#             times = []
#             cloud_cover = []
#             temperatures = []

#             for entry in weather_data['list']:
#                 dt = datetime.fromtimestamp(entry['dt']).strftime('%Y-%m-%d %H:%M:%S')
#                 times.append(dt)
#                 cloud_cover.append(entry['clouds']['all'])
#                 temperatures.append(entry['main']['temp'])

#             # Prepare results
#             time_info = "\n".join(times[:1])  # Show the first timestamp for simplicity
#             cloud_info = f"Cloud Cover: {cloud_cover[0]}%"  # Show the first cloud cover percentage
#             temp_info = f"Temperature: {temperatures[0]}°C"  # Show the first temperature
            
#             result_label.config(text=f"Time: {time_info}\n{cloud_info}\n{temp_info}")
#         else:
#             messagebox.showerror("Error", "City not found!")

#     except Exception as e:
#         messagebox.showerror("Error", "Unable to fetch weather data!")

# # Create the main window
# root = tk.Tk()
# root.title("Weather Forecasting")
# root.geometry("500x350")
# root["bg"] = "pink"

# # Title Label
# lbl_title = tk.Label(root, text="Weather Forecasting", font='arial 30 bold', borderwidth=2, relief="solid", bg="lightblue")
# lbl_title.pack(pady=5)

# # City Entry Label
# city_label = tk.Label(root, text="Enter city:", font='arial 15 bold', bg="lightblue")
# city_label.place(x=100, y=190)

# # City Entry Box
# city_entry = tk.Entry(root, width=15, font='arial 15 bold',bg="lightblue")
# city_entry.place(x=280, y=190)

# # Submit Button
# get_weather_button = tk.Button(root, text="Submit", padx=25, pady=5, font='arial 20 bold',bg="lightblue", command=get_weather)
# get_weather_button.place(x=160, y=260)

# # Result Label
# result_label = tk.Label(root, text="", font=("Helvetica", 10), bg="pink")
# result_label.pack(pady=20)

# # Start the Tkinter event loop
# root.mainloop()

